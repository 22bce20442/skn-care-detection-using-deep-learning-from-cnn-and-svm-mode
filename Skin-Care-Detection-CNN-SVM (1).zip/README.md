# Skin Care Detection using CNN and SVM

Complete working code included.