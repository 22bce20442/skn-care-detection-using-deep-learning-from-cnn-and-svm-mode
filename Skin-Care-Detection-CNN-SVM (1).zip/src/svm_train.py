
import numpy as np
import pickle
from sklearn.svm import SVC
from sklearn.model_selection import train_test_split

X = np.load("features.npy")
y = np.load("labels.npy")

X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2)

svm = SVC(kernel='linear')
svm.fit(X_train, y_train)

with open("models/svm_model.pkl", "wb") as f:
    pickle.dump(svm, f)
