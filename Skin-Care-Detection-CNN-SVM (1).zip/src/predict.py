
import tensorflow as tf
import pickle
import numpy as np
from tensorflow.keras.preprocessing import image

cnn = tf.keras.models.load_model("models/cnn_model.h5")

with open("models/svm_model.pkl", "rb") as f:
    svm = pickle.load(f)

img = image.load_img("sample.jpg", target_size=(224,224))
img_arr = image.img_to_array(img)/255.0
img_arr = np.expand_dims(img_arr, axis=0)

features = cnn.predict(img_arr)
prediction = svm.predict(features)

print("Predicted class:", prediction)
